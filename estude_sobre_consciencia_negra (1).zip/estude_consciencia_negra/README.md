# Estude Sobre Consciência Negra

Primeira versão de um blog educativo interativo, responsivo e estático.

## Como visualizar
1. Extraia o arquivo ZIP.
2. Abra `index.html` no navegador.
3. Para testar localmente, não é necessário instalar dependências.

## Arquivos
- `index.html`: estrutura e conteúdo das páginas.
- `styles.css`: identidade visual responsiva.
- `script.js`: busca de artigos, leituras em janela modal, quiz e glossário.

## O que já funciona
- Navegação por âncoras e menu móvel.
- Pesquisa/filtro dos artigos.
- Janelas de leitura para os quatro conceitos.
- Quiz interativo de quatro perguntas, com feedback e pontuação.
- Glossário clicável.
- Links para instituições e legislação.

## Antes de publicar
- Revise e amplie os textos com bibliografia confiável.
- Acrescente autoria, data de publicação, política editorial e contato.
- Verifique links e mantenha os dados estatísticos atualizados, sempre citando fonte e ano.
- Confira requisitos de acessibilidade, privacidade e eventuais regras da escola/instituição.
- Se desejar publicar artigos frequentemente sem editar arquivos, considere posteriormente um CMS.
- O site importa fontes do Google Fonts; se quiser funcionamento totalmente offline, remova o `@import` em `styles.css` e use fontes locais/de sistema.

Este protótipo não possui servidor, comentários, cadastro de usuários ou banco de dados. O quiz e o glossário funcionam no navegador e não enviam respostas a um servidor.
