const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];

const menuToggle = $("#menuToggle");
const mainNav = $("#mainNav");
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
$$(".main-nav a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));
$("#year").textContent = new Date().getFullYear();

// Searchable article list
$("#articleSearch").addEventListener("input", event => {
  const query = event.target.value.trim().toLocaleLowerCase("pt-BR");
  let visible = 0;
  $$(".article-row").forEach(row => {
    const match = (row.dataset.search + " " + row.innerText).toLocaleLowerCase("pt-BR").includes(query);
    row.hidden = !match;
    if (match) visible++;
  });
  $("#emptyState").hidden = visible !== 0;
});

// Short educational reading panels. Draft content should be reviewed and expanded with references before public launch.
const articles = {
  individual: {
    title: "Racismo individual: atitudes e responsabilidades",
    intro: "O racismo individual pode aparecer em ações, falas, decisões e comportamentos de uma pessoa que inferiorizam, excluem ou tratam alguém de maneira desigual por sua raça ou cor.",
    sections: [
      ["Como observar", "Analise o que foi dito ou feito, o contexto, quem foi afetado e se há estereótipos ou tratamento desigual. A intenção declarada não apaga automaticamente o impacto de uma atitude."],
      ["Exemplo para discussão", "Uma pessoa faz comentários depreciativos sobre o cabelo crespo de um colega e insiste mesmo depois de ele dizer que se sente desrespeitado. O comportamento deve ser analisado pelo conteúdo, pelo contexto e pelo efeito sobre a pessoa atingida."],
      ["Pergunta para refletir", "Como é possível reconhecer o impacto de uma atitude, ouvir a pessoa afetada e assumir responsabilidade sem reduzir a conversa a uma disputa sobre intenção?"]
    ]
  },
  institucional: {
    title: "Racismo institucional: quando as regras produzem desigualdade",
    intro: "O racismo institucional é estudado quando procedimentos, políticas, práticas ou decisões de uma instituição contribuem para resultados racialmente desiguais ou não enfrentam desigualdades persistentes.",
    sections: [
      ["O que investigar", "Observe critérios de seleção, distribuição de oportunidades, aplicação de regras, canais de denúncia, resultados ao longo do tempo e medidas de correção. Uma diferença estatística é um sinal para investigar, não uma explicação completa por si só."],
      ["Exemplo para discussão", "Uma escola encontra diferenças persistentes nas punições aplicadas a grupos raciais em situações comparáveis. A instituição pode revisar os registros, ouvir a comunidade e avaliar se os critérios são consistentes e justos."],
      ["Pergunta para refletir", "Que dados, escutas e mudanças de procedimento ajudariam uma instituição a verificar se está tratando todos de forma justa?"]
    ]
  },
  estrutural: {
    title: "Racismo estrutural: olhar além de um caso isolado",
    intro: "O racismo estrutural diz respeito à maneira como a sociedade pode reproduzir desigualdades raciais por meio de processos históricos, instituições, relações econômicas, práticas culturais e decisões acumuladas.",
    sections: [
      ["Por que a história importa", "A escravidão, a exclusão de direitos e as desigualdades construídas ao longo da história ajudam a explicar condições do presente. Estudar a estrutura significa relacionar processos e evidências, não atribuir toda situação a uma única causa."],
      ["Como estudar", "Compare indicadores de educação, renda, moradia, saúde e representação ao longo do tempo. Leia a metodologia, confira o período analisado e evite generalizações sobre indivíduos a partir de dados de grupos."],
      ["Pergunta para refletir", "Que mudanças em políticas públicas, práticas institucionais e relações sociais poderiam reduzir uma desigualdade persistente?"]
    ]
  },
  ambiental: {
    title: "Racismo ambiental: território, risco e direito à cidade",
    intro: "O conceito de racismo ambiental ajuda a investigar como danos ambientais e falta de infraestrutura podem afetar desproporcionalmente comunidades racializadas, incluindo populações negras, quilombolas e tradicionais.",
    sections: [
      ["O que observar", "Investigue acesso a saneamento, água potável, coleta de resíduos, moradia segura, áreas verdes e proteção contra enchentes ou contaminação. Considere também quem participa das decisões sobre o território."],
      ["Exemplo para discussão", "Uma comunidade vive há anos com alagamentos e saneamento precário, enquanto outras áreas recebem melhorias. Para avaliar a situação, é preciso consultar dados, ouvir moradores e examinar decisões e investimentos públicos."],
      ["Pergunta para refletir", "Quem está mais exposto ao risco, quem participa das decisões e quais medidas poderiam distribuir proteção e infraestrutura de forma mais justa?"]
    ]
  }
};
const dialog = $("#articleDialog");
function openArticle(key) {
  const article = articles[key];
  if (!article) return;
  const content = $("#dialogContent");
  content.replaceChildren();
  const heading = document.createElement("h2");
  heading.textContent = article.title;
  const intro = document.createElement("p");
  intro.textContent = article.intro;
  content.append(heading, intro);
  article.sections.forEach(([title, text]) => {
    const h = document.createElement("h3"); h.textContent = title;
    const p = document.createElement("p"); p.textContent = text;
    content.append(h, p);
  });
  const note = document.createElement("p");
  note.className = "article-note";
  note.textContent = "Material introdutório para estudo. Ao usar este conteúdo em trabalhos escolares, complemente a leitura com livros, pesquisas e fontes primárias.";
  content.append(note);
  if (typeof dialog.showModal === "function") dialog.showModal();
  else dialog.setAttribute("open", "");
}
$$("[data-open]").forEach(button => button.addEventListener("click", () => openArticle(button.dataset.open)));
$("#closeDialog").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
});

// Quiz
const questions = [
  {
    text: "Uma escola percebe que estudantes negros recebem punições mais severas que outros estudantes em situações semelhantes. A direção decide analisar registros e critérios disciplinares.",
    answers: ["É uma situação que pode indicar uma questão institucional e precisa ser investigada.", "É necessariamente apenas um conflito pessoal entre estudantes.", "Não pode ser estudada porque a escola tem regras próprias."],
    correct: 0,
    explanation: "Comparar registros e critérios pode ajudar a identificar se práticas da instituição contribuem para tratamento desigual. É importante analisar o contexto e as evidências antes de concluir."
  },
  {
    text: "Uma pessoa ridiculariza repetidamente os traços físicos de um colega negro e usa estereótipos raciais para justificar as piadas.",
    answers: ["É uma atitude individual que pode constituir discriminação racial.", "É racismo ambiental, pois acontece em um espaço compartilhado.", "Não pode ser racismo se a pessoa disser que estava brincando."],
    correct: 0,
    explanation: "O comportamento individual pode expressar racismo. Chamar uma fala de brincadeira não elimina automaticamente seu conteúdo ou impacto."
  },
  {
    text: "Pesquisadores observam desigualdades raciais persistentes em renda e acesso a oportunidades e estudam como história, políticas e práticas sociais se relacionam.",
    answers: ["É uma análise de processos estruturais.", "É apenas uma discussão sobre preferências individuais.", "É uma prova de que todos os indivíduos vivem a mesma experiência."],
    correct: 0,
    explanation: "A análise estrutural relaciona processos históricos, instituições e práticas sociais. Os dados devem ser interpretados com cuidado e não definem automaticamente a experiência de cada pessoa."
  },
  {
    text: "Uma comunidade negra enfrenta poluição e falta de saneamento por longo período e tem pouca participação nas decisões ambientais que afetam seu território.",
    answers: ["Pode ser uma situação a investigar pela perspectiva do racismo ambiental.", "É necessariamente apenas uma questão de comportamento individual.", "Não tem relação com justiça ambiental porque envolve infraestrutura."],
    correct: 0,
    explanation: "A exposição desigual a riscos e a falta de participação nas decisões são questões relevantes para investigar o racismo ambiental. É necessário consultar evidências locais e ouvir a comunidade."
  }
];
let questionIndex = 0;
let selectedAnswer = null;
let checked = false;
let score = 0;
function renderQuestion() {
  const q = questions[questionIndex];
  selectedAnswer = null; checked = false;
  $("#questionText").textContent = q.text;
  $("#quizCount").textContent = `PERGUNTA ${questionIndex + 1} DE ${questions.length}`;
  $("#progressFill").style.width = `${((questionIndex + 1) / questions.length) * 100}%`;
  $("#quizFeedback").hidden = true;
  $("#quizFeedback").replaceChildren();
  $("#checkAnswer").hidden = false;
  $("#checkAnswer").disabled = true;
  $("#checkAnswer").textContent = "Conferir resposta";
  $("#nextQuestion").hidden = true;
  $("#nextQuestion").textContent = questionIndex === questions.length - 1 ? "Ver resultado →" : "Próxima pergunta →";
  const list = $("#answerList"); list.replaceChildren();
  q.answers.forEach((answer, index) => {
    const label = document.createElement("label");
    label.className = "answer-option";
    const radio = document.createElement("input");
    radio.type = "radio"; radio.name = "quiz-answer"; radio.value = index;
    radio.addEventListener("change", () => {
      selectedAnswer = index;
      $$(".answer-option", list).forEach(item => item.classList.remove("selected"));
      label.classList.add("selected");
      $("#checkAnswer").disabled = false;
    });
    const span = document.createElement("span"); span.textContent = answer;
    label.append(radio, span); list.append(label);
  });
}
$("#checkAnswer").addEventListener("click", () => {
  if (selectedAnswer === null || checked) return;
  checked = true;
  const q = questions[questionIndex];
  if (selectedAnswer === q.correct) score++;
  $$(".answer-option", $("#answerList")).forEach((label, i) => {
    const radio = $("input", label); radio.disabled = true;
    if (i === q.correct) label.classList.add("correct");
    else if (i === selectedAnswer) label.classList.add("incorrect");
  });
  const feedback = $("#quizFeedback");
  const title = document.createElement("strong");
  title.textContent = selectedAnswer === q.correct ? "Boa análise!" : "Vamos aprofundar.";
  const explanation = document.createElement("span"); explanation.textContent = q.explanation;
  feedback.append(title, explanation); feedback.hidden = false;
  $("#checkAnswer").hidden = true;
  $("#nextQuestion").hidden = false;
});
$("#nextQuestion").addEventListener("click", () => {
  if (questionIndex < questions.length - 1) {
    questionIndex++; renderQuestion();
  } else {
    const card = $("#quizCard"); card.replaceChildren();
    const label = document.createElement("p"); label.className = "scenario-label"; label.textContent = "SEU RESULTADO";
    const title = document.createElement("h3"); title.textContent = `Você acertou ${score} de ${questions.length} perguntas.`;
    const description = document.createElement("p"); description.className = "quiz-feedback";
    description.textContent = score === questions.length ? "Excelente! Continue estudando e consulte as fontes para aprofundar sua análise." : "O quiz é um ponto de partida. Releia os conceitos e observe como o contexto e as evidências ajudam a interpretar cada situação.";
    const restart = document.createElement("button"); restart.className = "button button-dark"; restart.textContent = "Refazer quiz";
    restart.addEventListener("click", () => { questionIndex = 0; score = 0; renderQuestion(); });
    card.append(label, title, description, restart);
  }
});
renderQuestion();

// Glossary
const glossary = {
  preconceito: ["Preconceito", "Julgamento ou ideia prévia sobre uma pessoa ou grupo, formado sem conhecimento suficiente e frequentemente associado a estereótipos."],
  discriminacao: ["Discriminação racial", "Tratamento desigual, exclusão ou restrição relacionada à raça, cor, descendência ou origem étnica, em contextos e formas que devem ser analisados com atenção."],
  equidade: ["Equidade", "Princípio que considera desigualdades e necessidades diferentes para buscar condições mais justas de acesso a direitos e oportunidades."],
  afirmativas: ["Ações afirmativas", "Medidas destinadas a enfrentar desigualdades históricas e ampliar oportunidades para grupos que enfrentam barreiras persistentes. Cotas são um exemplo, com regras específicas em cada política."],
  interseccionalidade: ["Interseccionalidade", "Abordagem que analisa como diferentes relações sociais, como raça, gênero e classe, podem se cruzar e produzir experiências específicas de desigualdade."],
  branquitude: ["Branquitude", "Conceito usado para estudar como ser socialmente reconhecido como branco pode se relacionar com normas, posições sociais e privilégios em contextos marcados pelo racismo."]
};
$$(".term-button").forEach(button => button.addEventListener("click", () => {
  $$(".term-button").forEach(item => { item.classList.remove("active"); item.setAttribute("aria-selected", "false"); });
  button.classList.add("active"); button.setAttribute("aria-selected", "true");
  const [title, description] = glossary[button.dataset.term];
  $("#termTitle").textContent = title;
  $("#termDescription").textContent = description;
}));
